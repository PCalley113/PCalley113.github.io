// create empty arrays for sounds and colors
let s = [];
let colors = [];
// variable to store the current background color
let c;

function preload() {
   //load all 5 sound files before setup() runs
  s[0] = loadSound("beat.mp3");
  s[1] = loadSound("fireball.mp3");
  s[2] = loadSound("piano.mp3");
  s[3] = loadSound("sizzle.mp3");
  s[4] = loadSound("slam.mp3");
}

function setup() {
  // make a 400x400 pixel canvas
  createCanvas(400, 400);

  // fill the colors array with p5.js color objects
  colors.push(color(255, 0, 0));   // red
  colors.push(color(0, 255, 0));   // green
  colors.push(color(0, 0, 255));   // blue
  colors.push(color(255, 0, 255)); // magenta
  colors.push(color(0, 255, 255)); // cyan

  // start with the first color as background
  c = colors[0];

  // set the volume for each loaded sound
  for (let i = 0; i < s.length; i++) {
    s[i].setVolume(0.5);
  }
}

function draw() {
  // fill the background with the current color
  background(c);
}

function keyTyped() {
  // check which key is pressed
  // play the matching sound and change the color
  if (key == "a") {
    //s[0].play();
    c = colors[0];
  }
  if (key == "s") {
   // s[1].play();
    c = colors[1];
  }
  if (key == "d") {
   // s[2].play();
    c = colors[2];
  }
  if (key == "f") {
   // s[3].play();
    c = colors[3];
  }
  if (key == "g") {
   // s[4].play();
    c = colors[4];
  }

}
